package com.bolsadeideas.springboot.datajpa.app.springbootdatajpa;




class SpringBootDataJpaApplicationTests {

	
	void contextLoads() {
	}

}
